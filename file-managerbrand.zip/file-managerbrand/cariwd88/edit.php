<?php

$base_url = 'https://aspenstory.com';

?>