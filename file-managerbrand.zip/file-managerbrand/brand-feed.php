<?php
session_start();

/*
|--------------------------------------------------------------------------
| BRAND FEED CENTER + SPLIT SYNC FILES
|--------------------------------------------------------------------------
| Pusat:
|   tokped.top/brand-feed.php
|
| Subdomain:
|   sync-samson88.php
|   sync-cariwd88.php
|   sync-karinbet.php
|   sync-jamur4d.php
|
| Jadi tidak perlu edit $BRAND lagi.
| Saat hubungkan subdomain, pilih brand dan Sync URL otomatis:
|   https://subdomain/sync-karinbet.php
|--------------------------------------------------------------------------
*/

$USERNAME = "admin";
$PASSWORD = "Admin123!@#12";
$SECRET_TOKEN = "TkpD_2026_x9Kp72LmQz_88Brand_5sAq";

$BRANDS = [
    "samson88" => [
        "label" => "SAMSON88",
        "file" => "edit-samson88.php",
        "sync_file" => "sync-samson88.php",
        "default" => "https://samson88slot.com",
    ],
    "cariwd88" => [
        "label" => "CARIWD88",
        "file" => "edit-cariwd88.php",
        "sync_file" => "sync-cariwd88.php",
        "default" => "https://cariwd88.com",
    ],
    "jamur4d" => [
        "label" => "JAMUR4D",
        "file" => "edit-jamur4d.php",
        "sync_file" => "sync-jamur4d.php",
        "default" => "https://jamur4d.com",
    ],
    "karinbet" => [
        "label" => "KARINBET",
        "file" => "edit-karinbet.php",
        "sync_file" => "sync-karinbet.php",
        "default" => "https://karinbetu.top",
    ],
];

$DATA_FILE = __DIR__ . "/brand-feed-data.json";
$REGISTRY_FILE = __DIR__ . "/brand-subdomains.json";

function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,"UTF-8");}

function clean_url($u){
    $u=trim($u);
    $u=rtrim($u,"/");
    if($u==="") return false;
    if(!preg_match('/^https?:\/\//i',$u)) $u="https://".$u;
    return filter_var($u,FILTER_VALIDATE_URL)?$u:false;
}

function clean_host($host){
    $host=trim(strtolower($host));
    $host=preg_replace('/^https?:\/\//i','',$host);
    $host=trim($host,"/");
    $host=strtok($host,"/");
    if(!preg_match('/^[a-z0-9.-]+$/i',$host)) return false;
    return $host;
}

function make_sync_url($host,$brand){
    global $BRANDS;
    $host=clean_host($host);
    if(!$host || empty($BRANDS[$brand])) return false;
    return "https://".$host."/".$BRANDS[$brand]["sync_file"];
}

function edit_content($url){
    return "<?php\n\n\$base_url = ".var_export($url,true).";\n\n?>";
}

function load_data(){
    global $DATA_FILE,$BRANDS;
    if(!is_file($DATA_FILE)){
        $d=["version"=>date("YmdHis"),"updated_at"=>date("Y-m-d H:i:s"),"links"=>[]];
        foreach($BRANDS as $k=>$b)$d["links"][$k]=$b["default"];
        file_put_contents($DATA_FILE,json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
        return $d;
    }
    $d=json_decode(file_get_contents($DATA_FILE),true);
    if(!is_array($d))$d=["version"=>date("YmdHis"),"updated_at"=>date("Y-m-d H:i:s"),"links"=>[]];
    foreach($BRANDS as $k=>$b)if(empty($d["links"][$k]))$d["links"][$k]=$b["default"];
    return $d;
}

function save_data($links){
    global $DATA_FILE;
    $d=["version"=>date("YmdHis"),"updated_at"=>date("Y-m-d H:i:s"),"links"=>$links];
    file_put_contents($DATA_FILE,json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
    return $d;
}

function write_central_files($links){
    global $BRANDS;
    $ok=[];$fail=[];
    foreach($BRANDS as $k=>$b){
        $u=clean_url($links[$k]??"");
        if(!$u){$fail[]=$b["file"]." URL invalid";continue;}
        $target=__DIR__."/".$b["file"];
        if(@file_put_contents($target,edit_content($u))===false)$fail[]=$b["file"]." gagal ditulis";
        else {@chmod($target,0644);$ok[]=$b["file"];}
    }
    return [$ok,$fail];
}

function load_registry(){
    global $REGISTRY_FILE;
    if(!is_file($REGISTRY_FILE)){file_put_contents($REGISTRY_FILE,"[]");return [];}
    $r=json_decode(file_get_contents($REGISTRY_FILE),true);
    return is_array($r)?$r:[];
}

function save_registry($r){
    global $REGISTRY_FILE;
    file_put_contents($REGISTRY_FILE,json_encode(array_values($r),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
}

function add_registry($brand,$host,$sync_url=""){
    global $BRANDS;
    if(!isset($BRANDS[$brand])) return [false,"Brand tidak valid"];
    $host=clean_host($host);
    if(!$host) return [false,"Host/subdomain tidak valid"];

    $sync_url=trim($sync_url);
    if($sync_url==="") $sync_url=make_sync_url($host,$brand);
    $sync_url=clean_url($sync_url);

    if(!$sync_url || !preg_match('/\/sync-[a-z0-9_-]+\.php$/i',$sync_url)) {
        return [false,"Sync URL harus sync-brand, contoh sync-karinbet.php"];
    }

    $reg=load_registry();$found=false;
    foreach($reg as &$row){
        if(($row["host"]??"")===$host && ($row["brand"]??"")===$brand){
            $row["sync_url"]=$sync_url;
            $row["sync_file"]=$BRANDS[$brand]["sync_file"];
            $row["updated_at"]=date("Y-m-d H:i:s");
            $found=true;
            break;
        }
    }
    unset($row);

    if(!$found){
        $reg[]=[
            "brand"=>$brand,
            "host"=>$host,
            "sync_file"=>$BRANDS[$brand]["sync_file"],
            "sync_url"=>$sync_url,
            "created_at"=>date("Y-m-d H:i:s"),
            "updated_at"=>date("Y-m-d H:i:s")
        ];
    }
    save_registry($reg);
    return [true,"Subdomain berhasil dihubungkan"];
}

function delete_registry($index){
    $reg=load_registry();
    if(isset($reg[$index])){
        unset($reg[$index]);
        save_registry($reg);
        return true;
    }
    return false;
}

function http_get($url){
    if(function_exists("curl_init")){
        $ch=curl_init($url);
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_TIMEOUT=>10,
            CURLOPT_FOLLOWLOCATION=>true,
            CURLOPT_SSL_VERIFYPEER=>false,
            CURLOPT_USERAGENT=>"TokpedPusher/1.0"
        ]);
        $body=curl_exec($ch);
        $err=curl_error($ch);
        $code=curl_getinfo($ch,CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ["ok"=>$body!==false&&$code>=200&&$code<400,"code"=>$code,"body"=>$body,"error"=>$err];
    }
    $body=@file_get_contents($url,false,stream_context_create(["http"=>["timeout"=>10,"user_agent"=>"TokpedPusher/1.0"]]));
    return ["ok"=>$body!==false,"code"=>$body!==false?200:0,"body"=>$body,"error"=>$body!==false?"":"failed"];
}

function push_all(){
    global $SECRET_TOKEN;
    $out=[];
    foreach(load_registry() as $row){
        $url=($row["sync_url"]??"")."?force=1&token=".urlencode($SECRET_TOKEN);
        $r=http_get($url);
        $out[]=[
            "host"=>$row["host"]??"",
            "brand"=>$row["brand"]??"",
            "sync_url"=>$row["sync_url"]??"",
            "ok"=>$r["ok"],
            "code"=>$r["code"],
            "body"=>substr((string)$r["body"],0,250),
            "error"=>$r["error"]
        ];
    }
    return $out;
}

function test_one($idx){
    global $SECRET_TOKEN;
    $reg=load_registry();
    if(!isset($reg[$idx])) return [];
    $row=$reg[$idx];
    $url=($row["sync_url"]??"")."?force=1&token=".urlencode($SECRET_TOKEN);
    $r=http_get($url);
    return [[
        "host"=>$row["host"]??"",
        "brand"=>$row["brand"]??"",
        "sync_url"=>$row["sync_url"]??"",
        "ok"=>$r["ok"],
        "code"=>$r["code"],
        "body"=>substr((string)$r["body"],0,250),
        "error"=>$r["error"]
    ]];
}

if(isset($_GET["api"])){
    header("Content-Type: application/json");
    if(!hash_equals($SECRET_TOKEN,$_GET["token"]??"")){
        http_response_code(403);
        echo json_encode(["ok"=>false,"error"=>"Invalid token"]);
        exit;
    }
    $brand=strtolower(trim($_GET["brand"]??""));
    if(!isset($BRANDS[$brand])){
        http_response_code(404);
        echo json_encode(["ok"=>false,"error"=>"Invalid brand"]);
        exit;
    }
    $d=load_data();
    echo json_encode([
        "ok"=>true,
        "brand"=>$brand,
        "version"=>$d["version"],
        "updated_at"=>$d["updated_at"],
        "base_url"=>$d["links"][$brand]
    ],JSON_UNESCAPED_SLASHES);
    exit;
}

if(isset($_GET["logout"])){
    session_destroy();
    header("Location: brand-feed.php");
    exit;
}

$error="";$msg="";$push=[];$data=load_data();

if($_SERVER["REQUEST_METHOD"]==="POST"&&isset($_POST["login"])){
    if(($_POST["username"]??"")===$USERNAME && ($_POST["password"]??"")===$PASSWORD){
        $_SESSION["bf_login"]=true;
        header("Location: brand-feed.php");
        exit;
    }
    $error="Username atau password salah.";
}

if(!isset($_SESSION["bf_login"])){
?><!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Brand Feed Login</title><style>
body{margin:0;font-family:Arial;background:linear-gradient(135deg,#e0f7ff,#38bdf8);min-height:100vh;display:flex;align-items:center;justify-content:center;color:#083344}.box{width:100%;max-width:380px;background:rgba(255,255,255,.88);border-radius:20px;padding:24px;box-shadow:0 18px 45px rgba(2,132,199,.28)}h1{text-align:center;color:#0369a1}input,button{width:100%;padding:13px;margin-bottom:12px;border-radius:12px;box-sizing:border-box}input{border:1px solid #7dd3fc;background:#f0f9ff}button{border:0;background:#0ea5e9;color:#fff;font-weight:900}.err{background:#fee2e2;color:#991b1b;padding:10px;border-radius:10px;margin-bottom:12px}
</style></head><body><div class="box"><h1>Brand Feed Center</h1><?php if($error):?><div class="err"><?=e($error)?></div><?php endif;?><form method="post"><input name="username" placeholder="Username" required><input type="password" name="password" placeholder="Password" required><button name="login">MASUK</button></form></div></body></html><?php exit;
}

if($_SERVER["REQUEST_METHOD"]==="POST"&&isset($_POST["save_links"])){
    $links=[];$bad=false;
    foreach($BRANDS as $k=>$b){
        $u=clean_url($_POST["links"][$k]??"");
        if(!$u){$msg="URL ".$b["label"]." tidak valid.";$bad=true;break;}
        $links[$k]=$u;
    }
    if(!$bad){
        $data=save_data($links);
        [$ok,$fail]=write_central_files($links);
        $msg="Link pusat disimpan. File pusat: ".count($ok)." sukses, ".count($fail)." gagal.";
    }
}

if($_SERVER["REQUEST_METHOD"]==="POST"&&isset($_POST["push_now"])){
    $push=push_all();
    $okc=0;foreach($push as $p)if($p["ok"])$okc++;
    $msg="Penyebaran selesai. Berhasil: ".$okc.". Gagal: ".(count($push)-$okc).".";
}

if($_SERVER["REQUEST_METHOD"]==="POST"&&isset($_POST["add_subdomain"])){
    [$ok,$message]=add_registry(strtolower(trim($_POST["sub_brand"]??"")),trim($_POST["sub_host"]??""),trim($_POST["sub_sync_url"]??""));
    $msg=$message;
}

if($_SERVER["REQUEST_METHOD"]==="POST"&&isset($_POST["delete_subdomain"])){
    delete_registry((int)($_POST["idx"]??-1));
    $msg="Subdomain dihapus dari daftar.";
}

if($_SERVER["REQUEST_METHOD"]==="POST"&&isset($_POST["test_subdomain"])){
    $push=test_one((int)($_POST["idx"]??-1));
    $msg="Test sync selesai.";
}

$registry=load_registry();
?><!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tokped Brand Feed Split Sync</title><style>
*{box-sizing:border-box}body{font-family:Arial;margin:0;background:linear-gradient(135deg,#e0f7ff,#38bdf8);color:#083344}.top{background:rgba(255,255,255,.78);padding:14px;display:flex;justify-content:space-between;box-shadow:0 8px 26px rgba(2,132,199,.18)}.top b{color:#0369a1}.top a{background:#0284c7;color:white;text-decoration:none;padding:8px 11px;border-radius:10px;font-weight:800}.wrap{padding:16px;max-width:1150px;margin:auto}.card{background:rgba(255,255,255,.85);border-radius:18px;padding:16px;margin-bottom:14px;box-shadow:0 14px 35px rgba(2,132,199,.18)}.title{font-weight:900;color:#075985;font-size:18px;margin-bottom:10px}.row{display:grid;grid-template-columns:180px 1fr;gap:10px;align-items:center;margin-bottom:10px}.label{font-weight:900;color:#075985}input[type=text],select{width:100%;padding:12px;border-radius:12px;border:1px solid #7dd3fc;background:#f0f9ff}button{padding:10px 12px;border:0;border-radius:10px;background:#0ea5e9;color:#fff;font-weight:900;cursor:pointer}.orange{background:#ea580c}.red{background:#dc2626}.green{background:#16a34a}.msg{background:#ecfeff;color:#075985;padding:10px;border-radius:12px;margin-bottom:12px;border:1px solid #7dd3fc;font-weight:700}.code{background:#0f172a;color:#e0f2fe;padding:10px;border-radius:10px;word-break:break-all;font-family:Consolas,monospace;font-size:13px;margin-bottom:7px}table{width:100%;border-collapse:collapse;background:white;border-radius:12px;overflow:hidden}td,th{padding:9px;border-bottom:1px solid #bae6fd;text-align:left;font-size:13px;vertical-align:top}th{background:#bae6fd;color:#075985}.actions form{display:inline-block;margin:2px}.grid3{display:grid;grid-template-columns:160px 1fr 1fr auto;gap:8px;align-items:center}@media(max-width:800px){.row,.grid3{grid-template-columns:1fr}}
</style></head><body><div class="top"><div><b>Tokped Brand Feed Split Sync</b><br><span>sync file dipisah per brand, tanpa edit $BRAND</span></div><div><a href="?logout=1">Logout</a></div></div><div class="wrap">
<?php if($msg):?><div class="msg"><?=e($msg)?></div><?php endif;?>
<div class="card"><div class="title">Update Link Pusat 4 Brand</div><form method="post" onsubmit="return confirm('Yakin simpan link pusat?')"><?php foreach($BRANDS as $k=>$b):?><div class="row"><div class="label"><?=e($b["label"])?><br><small><?=e($b["file"])?></small><br><small><?=e($b["sync_file"])?></small></div><input type="text" name="links[<?=e($k)?>]" value="<?=e($data["links"][$k]??$b["default"])?>" required></div><?php endforeach;?><button name="save_links">Simpan Link Pusat</button></form></div>
<div class="card"><div class="title">Tombol Penyebar</div><form method="post" onsubmit="return confirm('Yakin sebar update ke semua subdomain terdaftar?')"><button class="orange" name="push_now">Sebarkan Sekarang ke Semua Subdomain</button></form></div>
<div class="card"><div class="title">Tabel Redirect / Subdomain Terhubung</div><table><tr><th>No</th><th>Brand</th><th>Host</th><th>Sync File</th><th>Sync URL</th><th>Aksi</th></tr><?php if(empty($registry)):?><tr><td colspan="6">Belum ada subdomain.</td></tr><?php else:$n=1;foreach($registry as $idx=>$r):?><tr><td><?=$n++?></td><td><?=e($r["brand"]??"")?></td><td><?=e($r["host"]??"")?></td><td><?=e($r["sync_file"]??"")?></td><td><code><?=e($r["sync_url"]??"")?></code></td><td class="actions"><form method="post"><input type="hidden" name="idx" value="<?=$idx?>"><button class="green" name="test_subdomain">Test Sync</button></form><form method="post" onsubmit="return confirm('Hapus subdomain ini?')"><input type="hidden" name="idx" value="<?=$idx?>"><button class="red" name="delete_subdomain">Hapus</button></form></td></tr><?php endforeach;endif;?></table></div>
<div class="card"><div class="title">Hubungkan Subdomain Baru</div><form method="post"><div class="grid3"><select name="sub_brand" required><?php foreach($BRANDS as $k=>$b):?><option value="<?=e($k)?>"><?=e($b["label"])?> — <?=e($b["sync_file"])?></option><?php endforeach;?></select><input type="text" name="sub_host" placeholder="contoh: mantab.tokped.top" required><input type="text" name="sub_sync_url" placeholder="kosongkan: otomatis sesuai brand"><button name="add_subdomain">Hubungkan</button></div></form><p>Pilih brand, isi host. Sync URL bisa kosong karena otomatis memilih sync-karinbet.php / sync-samson88.php / dll.</p></div>
<?php if($push):?><div class="card"><div class="title">Hasil Sync / Penyebaran</div><?php foreach($push as $p):?><div class="code"><?=!empty($p["ok"])?"✅":"❌"?> <?=e($p["host"])?> | <?=e($p["brand"])?> | HTTP <?=e($p["code"])?><br><?=e($p["body"] ?: $p["error"])?></div><?php endforeach;?></div><?php endif;?>
<div class="card"><div class="title">Status Feed</div><div class="code">version: <?=e($data["version"]??"")?></div><div class="code">updated_at: <?=e($data["updated_at"]??"")?></div><?php foreach($BRANDS as $k=>$b):?><div class="code"><?=e($b["label"])?> API: https://<?=e($_SERVER["HTTP_HOST"])?><?=e($_SERVER["PHP_SELF"])?>?api=1&brand=<?=e($k)?>&token=<?=e($SECRET_TOKEN)?></div><?php endforeach;?></div>
</div></body></html>
