<?php

$base_url = 'https://karinbetu.top';

?>