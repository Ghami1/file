<?php

$base_url = 'https://52.221.103.162';

?>