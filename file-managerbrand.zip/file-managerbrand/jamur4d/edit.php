<?php

$base_url = 'https://jamur4d.store';

?>