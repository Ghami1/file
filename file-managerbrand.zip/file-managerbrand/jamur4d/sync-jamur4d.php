<?php
$BRAND = "jamur4d";
$FEED_URL = "https://tokped.top/brand-feed.php";
$SECRET_TOKEN = "TkpD_2026_x9Kp72LmQz_88Brand_5sAq";

$LOCAL_EDIT_FILE = __DIR__ . "/edit.php";
$LOCAL_VERSION_FILE = __DIR__ . "/.brand_version_" . $BRAND;
$LOCAL_LAST_CHECK_FILE = __DIR__ . "/.brand_last_check_" . $BRAND;
$LOCAL_LOG_FILE = __DIR__ . "/.brand_sync_" . $BRAND . ".log";
$CHECK_INTERVAL = 300;

function brand_log($m){global $LOCAL_LOG_FILE;@file_put_contents($LOCAL_LOG_FILE,"[".date("Y-m-d H:i:s")."] ".$m."\n",FILE_APPEND);}
function fetch_url($url,$timeout=6){
    if(function_exists("curl_init")){
        $ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>$timeout,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_USERAGENT=>"BrandSync/1.0"]);
        $r=curl_exec($ch);$e=curl_error($ch);$c=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
        if($r===false||$c<200||$c>=400){brand_log("HTTP $c $e");return false;}
        return $r;
    }
    return @file_get_contents($url,false,stream_context_create(["http"=>["timeout"=>$timeout,"user_agent"=>"BrandSync/1.0"]]));
}
function valid_url($u){$u=rtrim(trim($u),"/");return (preg_match('/^https?:\/\/[a-zA-Z0-9.-]+/i',$u)&&filter_var($u,FILTER_VALIDATE_URL))?$u:false;}
function write_edit($u){
    global $LOCAL_EDIT_FILE;
    $c="<?php\n\n\$base_url = ".var_export($u,true).";\n\n?>";
    $ok=@file_put_contents($LOCAL_EDIT_FILE,$c);
    if($ok!==false){@chmod($LOCAL_EDIT_FILE,0644);return true;}
    return false;
}
function sync_brand_now($force=false){
    global $BRAND,$FEED_URL,$SECRET_TOKEN,$LOCAL_VERSION_FILE,$LOCAL_LAST_CHECK_FILE,$CHECK_INTERVAL;
    $now=time();$last=is_file($LOCAL_LAST_CHECK_FILE)?(int)trim(file_get_contents($LOCAL_LAST_CHECK_FILE)):0;
    if(!$force&&($now-$last)<$CHECK_INTERVAL)return ["ok"=>true,"message"=>"Skip interval"];
    @file_put_contents($LOCAL_LAST_CHECK_FILE,(string)$now);
    $r=fetch_url($FEED_URL."?api=1&brand=".urlencode($BRAND)."&token=".urlencode($SECRET_TOKEN),6);
    if(!$r)return ["ok"=>false,"message"=>"Feed gagal diambil"];
    $d=json_decode($r,true);
    if(!is_array($d)||empty($d["ok"]))return ["ok"=>false,"message"=>"Feed invalid"];
    $version=trim($d["version"]??"");$url=valid_url($d["base_url"]??"");
    if($version===""||!$url)return ["ok"=>false,"message"=>"Data invalid"];
    $lv=is_file($LOCAL_VERSION_FILE)?trim(file_get_contents($LOCAL_VERSION_FILE)):"";
    if($lv===$version&&!$force)return ["ok"=>true,"message"=>"Sudah terbaru"];
    if(!write_edit($url))return ["ok"=>false,"message"=>"Gagal tulis edit.php"];
    @file_put_contents($LOCAL_VERSION_FILE,$version);
    return ["ok"=>true,"message"=>"Updated $BRAND to $url"];
}
if(basename($_SERVER["SCRIPT_FILENAME"]??"")===basename(__FILE__)){
    header("Content-Type:text/plain");
    $force=isset($_GET["force"])||hash_equals($SECRET_TOKEN,$_GET["token"]??"");
    $r=sync_brand_now($force);
    echo ($r["ok"]?"OK: ":"ERROR: ").$r["message"]."\n";
    exit;
}
?>