<?php
session_start();


$USERNAME = "jamur4d";
$PASSWORD = "Admin123!@#12";

// Root file manager = folder parent dari /manager
$ROOT = realpath(__DIR__ . "/..");

// File yang boleh diedit
$EDIT_ALLOWED = [
    "edit.php",
];

// File / folder yang disembunyikan dari list
$HIDE_ITEMS = [
    ".htaccess",
    "assets",
    "cgi-bin",
    ".well-known",
    "sys-login-84kq",
    "wp-config.php",
    "configuration.php",
    ".env",
    "config.php",
    "database.php",
    "edit.php",
];

function safe_path($path) {
    global $ROOT;

    $path = trim($path ?? "", "/");

    if ($path === "") {
        return $ROOT;
    }

    $full = realpath($ROOT . "/" . $path);

    if ($full === false) {
        $full = $ROOT . "/" . $path;
        $checkBase = realpath(dirname($full));
    } else {
        $checkBase = is_dir($full) ? $full : realpath(dirname($full));
    }

    if ($checkBase === false) {
        $checkBase = $ROOT;
    }

    // Pastikan tidak bisa keluar dari root subdomain
    if (strpos($checkBase, $ROOT) !== 0) {
        die("Access denied");
    }

    return $full;
}

function rel_path($full) {
    global $ROOT;
    return trim(str_replace($ROOT, "", $full), "/");
}

function can_edit($rel) {
    global $EDIT_ALLOWED;
    return in_array(basename($rel), $EDIT_ALLOWED);
}

function web_url($rel) {
    $rel = trim($rel, "/");

    // Kalau file index.php / index.html di root, buka /
    if ($rel === "index.php" || $rel === "index.html") {
        return "/";
    }

    // Kalau file .html, buka versi tanpa .html
    if (preg_match('/\.html$/i', $rel)) {
        $rel = preg_replace('/\.html$/i', '', $rel);
    }

    // Kalau file .php, buka versi tanpa .php
    if (preg_match('/\.php$/i', $rel)) {
        $rel = preg_replace('/\.php$/i', '', $rel);
    }

    return "/" . $rel;
}

function clean_redirect_filename($name) {
    $name = trim($name);
    $name = basename($name);

    if ($name === "") {
        return false;
    }

    // Spasi otomatis jadi strip
    $name = preg_replace('/\s+/', '-', $name);

    // Hanya huruf, angka, strip, underscore, dan optional .php
    if (!preg_match('/^[a-zA-Z0-9_-]+(\.php)?$/', $name)) {
        return false;
    }

    // Kalau belum ada .php, otomatis tambahkan
    if (!preg_match('/\.php$/i', $name)) {
        $name .= ".php";
    }

    return $name;
}

function clean_ref($ref) {
    $ref = trim($ref);

    if ($ref === "") {
        return false;
    }

    // Hanya boleh huruf, angka, strip, underscore
    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $ref)) {
        return false;
    }

    return $ref;
}


function clean_base_url($url) {
    $url = trim($url);
    $url = rtrim($url, "/");

    if ($url === "") {
        return false;
    }

    if (!preg_match('/^https?:\/\//i', $url)) {
        $url = "https://" . $url;
    }

    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }

    return $url;
}

function get_current_base_url() {
    global $ROOT;

    $file = $ROOT . "/edit.php";

    if (!is_file($file)) {
        return "";
    }

    $content = file_get_contents($file);

    if (preg_match('/\$base_url\s*=\s*[\'\"]([^\'\"]+)[\'\"]\s*;/i', $content, $m)) {
        return $m[1];
    }

    return "";
}

if (isset($_GET["logout"])) {
    session_destroy();
    header("Location: login");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["login"])) {
    if ($_POST["username"] === $USERNAME && $_POST["password"] === $PASSWORD) {
        $_SESSION["fm_login"] = true;
        header("Location: panel");
        exit;
    } else {
        $error = "Username atau password salah.";
    }
}

if (!isset($_SESSION["fm_login"])) {
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Manager Login</title>
<style>
*{
    box-sizing:border-box;
}

body{
    margin:0;
    font-family:Arial,sans-serif;
    background:
        radial-gradient(circle at top left, rgba(34,197,94,.26), transparent 28%),
        radial-gradient(circle at 85% 20%, rgba(16,185,129,.18), transparent 32%),
        linear-gradient(135deg,#020403,#04150d,#062c1a);
    color:#dcfce7;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:16px;
}

.box{
    width:100%;
    max-width:390px;
    background:rgba(3,20,12,.88);
    border:1px solid rgba(74,222,128,.55);
    border-radius:22px;
    padding:26px;
    box-shadow:0 18px 45px rgba(0,0,0,.45),0 0 30px rgba(34,197,94,.14);
    backdrop-filter:blur(14px);
}

h1{
    text-align:center;
    margin:0 0 18px;
    color:#86efac;
    letter-spacing:.3px;
    text-shadow:0 0 16px rgba(34,197,94,.35);
}

input{
    width:100%;
    padding:13px;
    margin-bottom:12px;
    border-radius:12px;
    border:1px solid rgba(74,222,128,.65);
    background:#07130d;
    color:#dcfce7;
    font-size:15px;
    outline:none;
}

input::placeholder{
    color:rgba(220,252,231,.55);
}

input:focus{
    border-color:#22c55e;
    box-shadow:0 0 0 3px rgba(34,197,94,.18);
}

button{
    width:100%;
    padding:13px;
    border:0;
    border-radius:12px;
    background:linear-gradient(135deg,#22c55e,#16a34a);
    color:#04150d;
    font-size:16px;
    font-weight:900;
    cursor:pointer;
    box-shadow:0 8px 20px rgba(34,197,94,.25);
}

button:hover{
    background:linear-gradient(135deg,#4ade80,#15803d);
}

.err{
    background:rgba(127,29,29,.85);
    color:#fee2e2;
    padding:10px;
    border-radius:10px;
    margin-bottom:12px;
    border:1px solid rgba(248,113,113,.55);
}

small{
    display:block;
    text-align:center;
    margin-top:12px;
    color:#bbf7d0;
}
</style>
</head>
<body>

<div class="box">
<h1>Login Manager</h1>

<?php if(isset($error)): ?>
<div class="err"><?=htmlspecialchars($error)?></div>
<?php endif; ?>

<form method="post">
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit" name="login">MASUK</button>
</form>

<small>Protected File Manager</small>
</div>

<script>
function copyLink(url, btn){
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(url).then(function(){
            var oldText = btn.innerText;
            btn.innerText = "Copied";
            setTimeout(function(){ btn.innerText = oldText; }, 1200);
        }).catch(function(){
            fallbackCopy(url, btn);
        });
    } else {
        fallbackCopy(url, btn);
    }
}

function fallbackCopy(url, btn){
    var temp = document.createElement("input");
    temp.value = url;
    document.body.appendChild(temp);
    temp.select();
    document.execCommand("copy");
    document.body.removeChild(temp);

    var oldText = btn.innerText;
    btn.innerText = "Copied";
    setTimeout(function(){ btn.innerText = oldText; }, 1200);
}
</script>

</body>
</html>
<?php
exit;
}

$dir = $_GET["dir"] ?? "";
$current = safe_path($dir);

if (!is_dir($current)) {
    $current = $ROOT;
    $dir = "";
}

$msg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Ganti link utama di edit.php
    if (isset($_POST["update_base_url"])) {
        $newBaseUrl = clean_base_url($_POST["base_url"] ?? "");

        if (!$newBaseUrl) {
            $msg = "Link utama tidak valid.";
        } else {
            $editFile = $ROOT . "/edit.php";

            $content = "<?php\n\n";
            $content .= "\$base_url = " . var_export($newBaseUrl, true) . ";\n\n";
            $content .= "?>";

            file_put_contents($editFile, $content);

            $msg = "Link utama berhasil diganti menjadi: " . $newBaseUrl;
        }
    }


    // Buat redirect dari kode ref
    if (isset($_POST["redirect_file"], $_POST["redirect_ref"])) {
        $newFile = clean_redirect_filename($_POST["redirect_file"]);
        $ref = clean_ref($_POST["redirect_ref"]);

        if (!$newFile) {
            $msg = "Nama file tidak valid. Contoh: daftar.php atau promo1";
        } elseif (!$ref) {
            $msg = "Kode ref tidak valid. Gunakan huruf, angka, strip, atau underscore.";
        } elseif (in_array($newFile, $HIDE_ITEMS)) {
            $msg = "Nama file tidak diizinkan.";
        } else {
            $target = $current . "/" . $newFile;

            if (file_exists($target)) {
                $msg = "File tujuan sudah ada.";
            } else {
                $content = "<?php\n";
                $content .= "include 'edit.php';\n";
                $content .= "header(\"Location: {\$base_url}/daftar?ref=" . $ref . "\");\n";
                $content .= "exit;\n";
                $content .= "?>";

                file_put_contents($target, $content);
                $msg = "Redirect berhasil dibuat: " . $newFile . " dengan ref: " . $ref;
            }
        }
    }

}

// Delete dimatikan demi keamanan
if (isset($_GET["delete"])) {
    die("Delete disabled");
}

if (isset($_GET["download"])) {
    die("Download disabled");
}

if (isset($_GET["edit"])) {
    die("Edit disabled");
}

$items = scandir($current);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>jAMUR4D</title>
<style>
*{
    box-sizing:border-box;
}

body{
    font-family:Arial,sans-serif;
    margin:0;
    background:
        radial-gradient(circle at top left, rgba(34,197,94,.22), transparent 24%),
        radial-gradient(circle at 90% 18%, rgba(16,185,129,.15), transparent 30%),
        linear-gradient(135deg,#020403,#04150d,#062c1a);
    color:#dcfce7;
    min-height:100vh;
}

.top{
    background:rgba(3,20,12,.88);
    border-bottom:1px solid rgba(74,222,128,.45);
    padding:14px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:8px;
    flex-wrap:wrap;
    box-shadow:0 8px 26px rgba(0,0,0,.38);
    backdrop-filter:blur(14px);
}

.top b{
    color:#86efac;
    font-size:18px;
    text-shadow:0 0 14px rgba(34,197,94,.32);
}

.top a{
    color:#04150d;
    background:linear-gradient(135deg,#22c55e,#16a34a);
    border:1px solid rgba(74,222,128,.65);
    border-radius:10px;
    padding:8px 11px;
    text-decoration:none;
    font-size:13px;
    font-weight:900;
}

.top a:hover{
    background:linear-gradient(135deg,#4ade80,#15803d);
}

.wrap{
    padding:14px;
    max-width:1150px;
    margin:auto;
}

.card{
    background:rgba(3,20,12,.82);
    border:1px solid rgba(74,222,128,.38);
    border-radius:18px;
    padding:14px;
    margin-bottom:14px;
    box-shadow:0 14px 35px rgba(0,0,0,.35),0 0 28px rgba(34,197,94,.08);
    backdrop-filter:blur(12px);
}

.card-title{
    color:#86efac;
    font-weight:900;
    margin-bottom:9px;
}

.card-note{
    color:#bbf7d0;
    font-size:13px;
    margin-top:7px;
}

input[type=text]{
    padding:10px;
    border-radius:10px;
    border:1px solid rgba(74,222,128,.65);
    margin:4px 0;
    max-width:100%;
    background:#07130d;
    color:#dcfce7;
    outline:none;
}

input[type=text]::placeholder{
    color:rgba(220,252,231,.5);
}

input[type=text]:focus{
    border-color:#22c55e;
    box-shadow:0 0 0 3px rgba(34,197,94,.18);
}

button{
    padding:10px 13px;
    border:0;
    border-radius:10px;
    background:linear-gradient(135deg,#22c55e,#16a34a);
    color:#04150d;
    font-weight:900;
    cursor:pointer;
    box-shadow:0 8px 18px rgba(34,197,94,.22);
}

button:hover{
    background:linear-gradient(135deg,#4ade80,#15803d);
}

table{
    width:100%;
    border-collapse:collapse;
    background:rgba(3,20,12,.86);
    color:#dcfce7;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 14px 35px rgba(0,0,0,.35);
    border:1px solid rgba(74,222,128,.32);
}

th,td{
    border-bottom:1px solid rgba(74,222,128,.18);
    padding:10px;
    text-align:left;
    font-size:14px;
}

th{
    background:rgba(22,101,52,.78);
    color:#dcfce7;
    font-weight:900;
}

tr:hover{
    background:rgba(34,197,94,.09);
}

td a{
    color:#86efac;
    font-weight:800;
    text-decoration:none;
}

td a:hover{
    text-decoration:underline;
}

.no-col{
    width:58px;
    text-align:center;
    font-weight:900;
    color:#86efac;
}

.actions a{
    display:inline-block;
    margin:2px;
    padding:7px 9px;
    border-radius:8px;
    text-decoration:none;
    color:#04150d;
    background:#22c55e;
    font-size:12px;
    font-weight:900;
}

.actions a:hover{
    text-decoration:none;
    background:#4ade80;
}

.actions a.open{
    background:linear-gradient(135deg,#22c55e,#16a34a);
}

.actions button.copy{
    display:inline-block;
    margin:2px;
    padding:7px 9px;
    border-radius:8px;
    border:0;
    text-decoration:none;
    color:#fff;
    background:linear-gradient(135deg,#0f766e,#14b8a6);
    font-size:12px;
    font-weight:900;
    cursor:pointer;
    box-shadow:none;
}

.actions button.copy:hover{
    background:linear-gradient(135deg,#0d9488,#2dd4bf);
    transform:none;
}

.path{
    font-size:13px;
    color:#bbf7d0;
    word-break:break-all;
    font-weight:700;
}

.msg{
    background:rgba(20,83,45,.88);
    color:#dcfce7;
    padding:10px;
    border-radius:12px;
    margin-bottom:12px;
    border:1px solid rgba(74,222,128,.5);
    font-weight:700;
}

@media(max-width:720px){
    table,thead,tbody,tr,td,th{
        display:block;
    }

    th{
        display:none;
    }

    td{
        border-bottom:0;
    }

    tr{
        border-bottom:1px solid rgba(74,222,128,.18);
        padding:8px 0;
    }

    .actions a{
        font-size:11px;
    }
}
</style>
</head>
<body>

<div class="top">
<div>
<b>JAMUR4D</b><br>
<span class="path">/<?=htmlspecialchars($dir)?></span>
</div>

<div>
<a href="panel">Root</a>
<a href="?logout=1">Logout</a>
</div>
</div>

<div class="wrap">

<?php if($msg): ?>
<div class="msg"><?=htmlspecialchars($msg)?></div>
<?php endif; ?>

<?php
$currentBaseUrl = get_current_base_url();
?>

<div class="card">
<div class="card-title">Ganti Link Utama</div>

<form method="post">
<input type="text" name="base_url" placeholder="https://domainbaru.com" value="<?=htmlspecialchars($currentBaseUrl)?>" required>
<button type="submit" name="update_base_url">Simpan Link</button>
</form>

<div class="card-note">
Link ini akan dipakai semua file redirect yang menggunakan isi edit.php
</div>
</div>

<div class="card">
<div class="card-title">Buat Link Redirect</div>

<form method="post">
<input type="text" name="redirect_file" placeholder="nama-file.php" required>
<input type="text" name="redirect_ref" placeholder="kode ref, contoh: gacorboss" required>
<button type="submit">Buat Redirect</button>
</form>

<div class="card-note">
langsung isi file format .php dan nama referral contoh ( gacorboss )
</div>
</div>


<table>
<thead>
<tr>
<th>No</th>
<th>Nama</th>
<th>Tipe</th>
<th>Ukuran</th>
<th>Aksi</th>
</tr>
</thead>

<tbody>
<?php
if ($dir) {
    $parent = dirname($dir);

    if ($parent == ".") {
        $parent = "";
    }

    echo "<tr>";
    echo "<td>-</td>";
    echo "<td><a href='panel?dir=".urlencode($parent)."'>⬅ ..</a></td>";
    echo "<td>Folder</td>";
    echo "<td>-</td>";
    echo "<td></td>";
    echo "</tr>";
}

$no = 1;

foreach ($items as $item) {
    if ($item === "." || $item === "..") continue;
    if (in_array($item, $HIDE_ITEMS)) continue;

    $full = $current . "/" . $item;
    $rel = trim(($dir ? $dir . "/" : "") . $item, "/");
    $isDir = is_dir($full);
    $type = $isDir ? "Folder" : "File";
    $size = $isDir ? "-" : number_format(filesize($full)) . " B";

    echo "<tr>";
    echo "<td class='no-col'>".$no++."</td>";
    echo "<td>";

    if ($isDir) {
        echo "📁 <a href='panel?dir=".urlencode($rel)."'>".htmlspecialchars($item)."</a>";
    } else {
        echo "📄 ".htmlspecialchars($item);
    }

    echo "</td>";
    echo "<td>$type</td>";
    echo "<td>$size</td>";
    echo "<td class='actions'>";

    if (!$isDir) {
        $publicUrl = web_url($rel);
        $fullPublicUrl = ((isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] === "on") ? "https://" : "http://") . $_SERVER["HTTP_HOST"] . $publicUrl;

        echo "<a class='open' target='_blank' href='".htmlspecialchars($publicUrl)."'>Buka</a>";
        echo "<button type='button' class='copy' onclick=\"copyLink('".htmlspecialchars($fullPublicUrl, ENT_QUOTES)."', this)\">Copy Link</button>";
    }

    echo "</td>";
    echo "</tr>";
}
?>
</tbody>
</table>

</div>
<script>
function copyLink(url, btn){
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(url).then(function(){
            var oldText = btn.innerText;
            btn.innerText = "Copied";
            setTimeout(function(){ btn.innerText = oldText; }, 1200);
        }).catch(function(){
            fallbackCopy(url, btn);
        });
    } else {
        fallbackCopy(url, btn);
    }
}

function fallbackCopy(url, btn){
    var temp = document.createElement("input");
    temp.value = url;
    document.body.appendChild(temp);
    temp.select();
    document.execCommand("copy");
    document.body.removeChild(temp);

    var oldText = btn.innerText;
    btn.innerText = "Copied";
    setTimeout(function(){ btn.innerText = oldText; }, 1200);
}
</script>

</body>
</html>